# Thaidessert > 2024-03-28 2:30pm
https://universe.roboflow.com/jeerakit-ferry/thaidessert-bo14h

Provided by a Roboflow user
License: CC BY 4.0

